package com.arraylist;

import java.util.ArrayList;
import java.util.List;

public class DisplayArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(1, "Ravi","Delhi","A","6688993456","abc@e",75000));
		 list.add(new Employee(2, "Raj","Mumbai","A","8899546372","def@e",55000));
		 list.add(new Employee(3, "Rekha","Chennai","B","9696785466","ghi@e",35000));
		 list.add(new Employee(4, "Ram","Siliguri","B","6688993456","abc@e",15000));

		 for (Employee s : list)
		 {
			 System.out.print(" employee details : ");
			 System.out.println(s.getId()+" "+s.getName()+" " +s.getAddress()+" "+s.getGrade()+" "+s.getMobno()+" "+s.getEmail()+" "+s.getSalary());
		 }

	}

}
