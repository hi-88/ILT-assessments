package InterfaceSegregation;

public interface HDMI {
public void SupportHDMI();

}
