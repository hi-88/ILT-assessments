package SingleResponsibilityPrinciple;

public class circle {
	//A class should have only one responsibility
double calcArea(double radius){
	return (Math.PI*radius*radius);
}
}
