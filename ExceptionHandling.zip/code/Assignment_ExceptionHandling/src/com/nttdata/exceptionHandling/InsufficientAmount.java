package com.nttdata.exceptionHandling;

public class InsufficientAmount extends Exception {
	public InsufficientAmount(String message)
	{
		super(message);
	}
}
