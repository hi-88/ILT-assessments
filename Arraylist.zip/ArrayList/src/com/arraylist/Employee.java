package com.arraylist;

public class Employee {

	int id;
	String name;
	String address;
	String grade;
	String email;
	String mobno;
	double salary;
	public Employee(int id, String name, String address, String grade, String email, String mobno, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.grade = grade;
		this.email = email;
		this.mobno = mobno;
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
