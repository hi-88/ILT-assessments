package com.fd;

public class Samsung extends Mobile{

	@Override
	public double getTax() {
		return 14;		
	}

}
