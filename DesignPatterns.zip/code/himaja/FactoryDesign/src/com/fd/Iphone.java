package com.fd;

public class Iphone extends Mobile {

	@Override
	public double getTax() {
		return 24.00;
		
	}

}
