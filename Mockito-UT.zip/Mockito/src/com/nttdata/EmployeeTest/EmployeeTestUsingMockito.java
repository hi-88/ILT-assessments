package com.nttdata.EmployeeTest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.nttdata.Dao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeTestUsingMockito {

	EmployeeDao employeeDao=Mockito.mock(EmployeeDao.class);
	@Test
	public void testListEmployee() 
	{
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(12,"spoorthi","bangalore"));
		list.add(new Employee(13,"sheethal","mysore"));
		list.add(new Employee(14,"Vani","udupi"));
		list.add(new Employee(15,"Monika","kolar"));
		list.add(new Employee(16,"chandana","dubai"));
		Mockito.when(employeeDao.list()).thenReturn(list);
	}	
	@Test
	public void testCreateEmployee()
	{
		Employee employee=new Employee(17,"deeksha","bihar");
		Mockito.when(employeeDao.createEmployee()).thenReturn(employee);
		
	}
	
	@Test
	public void testdeleteEmployee()
	{
		Employee employee=new Employee(16,"chandana","dubai");
		Mockito.when(employeeDao.deleteEmployee(16)).thenReturn(employee);
		
	}
	@Test
	public void testGetEmployeeId()
	{
		Employee employee=new Employee(15,"Monika","kolar");
		Mockito.when(employeeDao.getByEmployeeId(15)).thenReturn(employee);
		
	}
	@Test
	public void testSearchEmployeeByName()
	{
		Employee employee=new Employee(14,"Vani","udupi");
		Mockito.when(employeeDao.searchEmployeeByName("Vani")).thenReturn(employee);
		
	}
	

}
